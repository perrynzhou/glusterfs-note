/*
* Copyright(c) 2012-2019 Intel Corporation
* SPDX-License-Identifier: BSD-3-Clause-Clear
*/

#ifndef _UPGRADE_H
#define _UPGRADE_H

int upgrade_start();

#endif
