/*
* Copyright(c) 2012-2019 Intel Corporation
* SPDX-License-Identifier: BSD-3-Clause-Clear
*/
#ifndef __CAS_CONTROL_H__
#define __CAS_CONTROL_H__

int __init cas_ctrl_device_init(void);
void __exit cas_ctrl_device_deinit(void);

#endif
