/*
* Copyright(c) 2012-2019 Intel Corporation
* SPDX-License-Identifier: BSD-3-Clause-Clear
*/


#ifndef __CAS_UTILS_H__
#define __CAS_UTILS_H__

#include "utils_nvme.h"
#include "utils_properties.h"

#endif /* __CAS_UTILS_H__ */
