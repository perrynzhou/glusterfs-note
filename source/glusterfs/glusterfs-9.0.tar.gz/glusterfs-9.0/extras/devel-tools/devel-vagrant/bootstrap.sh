dnf install -y nfs-utils
dnf install -y vim
dnf install -y python2 python2-dnf libselinux-python libsemanage-python
